﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using Bryan.Apellanes;
using Bryan.Apellanes.CommandLine;
using Bryan.Apellanes.Data.Model;

namespace $safeprojectname$
{
    class Program : CommandLineMenuInterface
    {
        static void Main(string[] args)
        {
            // Set AssemblyToAnalyze to interact with 
            // classes from that assembly
            Start(args);
        }
    }
}
