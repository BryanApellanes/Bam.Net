using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Innovation;
using Innovation.Data;
using InnovationWeb.Model;
using Bam.Net.UserAccounts;

namespace InnovationWeb.Pages
{
    public class OptInModel : BetaProgramPageModel
    {
        public OptInModel(BetaProgramService service, IRoleReader roleReader) : base(service, roleReader)
        {
        }

        public List<BetaProgramParticipation> BetaProgramParticipants { get; set; }

        public override IActionResult OnGet()
        {
            BetaProgramParticipants = new List<BetaProgramParticipation>();
            string userName = User?.Identity?.Name;            
            if (!string.IsNullOrEmpty(userName))
            {
                BetaProgramResponse<List<BetaProgramParticipation>> response = BetaProgramService.GetParticipation(userName);
                if (!response.Success)
                {
                    Message = response.Message;
                }
                else
                {
                    BetaProgramParticipants = response.Data;
                }
            }

            return Page();
        }
    }
}