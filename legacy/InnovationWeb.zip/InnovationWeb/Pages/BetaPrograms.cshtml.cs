using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Bam.Net.UserAccounts;
using Innovation;
using Innovation.Data;
using InnovationWeb.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace InnovationWeb.Pages
{
    public class BetaProgramsModel : BetaProgramPageModel
    {
        public BetaProgramsModel(BetaProgramService service, IRoleReader roleReader) : base(service, roleReader)
        {
        }

        public override IActionResult OnGet()
        {
            if (!IsAdmin)
            {
                return Redirect("/AccessDenied");
            }
            return base.OnGet();
        }
    }
}