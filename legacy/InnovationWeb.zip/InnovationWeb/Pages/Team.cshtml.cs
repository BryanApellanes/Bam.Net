﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Bam.Net.UserAccounts;
using Innovation;
using InnovationWeb.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace InnovationWeb.Pages
{
    public class TeamModel : BetaProgramPageModel
    {
        public TeamModel(BetaProgramService service, IRoleReader roleReader) : base(service, roleReader)
        { }

        public string Message { get; set; }

        public override IActionResult OnGet()
        {
            Message = "Development Team";
            return Page();
        }
    }
}
