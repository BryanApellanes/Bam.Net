using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Bam.Net.UserAccounts;
using Innovation;
using Innovation.Data;
using InnovationWeb.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace InnovationWeb.Pages
{
    public class ParticipantsModel : BetaProgramPageModel
    {        
        public ParticipantsModel(BetaProgramService service, IRoleReader roleReader) : base(service, roleReader)
        {
            ParticipantsByProgram = new Dictionary<string, List<BetaProgramParticipant>>();
        }

        public Dictionary<string, List<BetaProgramParticipant>> ParticipantsByProgram { get; set; }

        public override IActionResult OnGet()
        {
            if (!IsAdmin)
            {
                return Redirect("/AccessDenied");
            }
            base.OnGet();
            foreach (BetaProgram program in BetaPrograms)
            {
                BetaProgramResponse<List<BetaProgramParticipant>> response = BetaProgramService.GetParticipants(program);
                if (response.Success)
                {
                    if (!ParticipantsByProgram.ContainsKey(program.Name))
                    {
                        ParticipantsByProgram.Add(program.Name, new List<BetaProgramParticipant>());
                    }
                    ParticipantsByProgram[program.Name].AddRange(response.Data);
                }
            }
            return Page();
        }
    }
}