using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Bam.Net.UserAccounts;
using Innovation;
using InnovationWeb.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace InnovationWeb.Pages
{
    public class OptInLinkModel : BetaProgramPageModel
    {
        public OptInLinkModel(BetaProgramService service, IRoleReader roleReader) : base(service, roleReader)
        { }

        public override IActionResult OnGet()
        {
            string userName = User?.Identity?.Name;
            if (!string.IsNullOrEmpty(userName))
            {
                string programName = Request.Query["programName"];
                if(!string.IsNullOrEmpty(programName))
                {
                    BetaProgramResponse<bool> response = BetaProgramService.OptIn(programName, userName);
                    Message = response.Message;
                    return Page();
                }
            }
            return Redirect("/");
        }
    }
}