﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Bam.Net.UserAccounts;
using Innovation;
using InnovationWeb.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace InnovationWeb.Pages
{
    public class AboutModel : BetaProgramPageModel
    {
        public AboutModel(BetaProgramService service, IRoleReader roleReader) : base(service, roleReader)
        { }

        public string Message { get; set; }

        public override IActionResult OnGet()
        {
            Message = "Innovation Test Kitchen";
            return Page();
        }
    }
}
