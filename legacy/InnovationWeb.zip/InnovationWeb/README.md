﻿# InnovationWeb
This project defines the application designed to allow Premera employees to opt-in to beta programs as they are defined.  It depends on 
InnovationSso for Active Directory based role definitiona, see [InnovationSso](../InnovationSso/).

## Source Control
The git repository is here https://dev.azure.com/premera-testkitchen/_git/TestKitchen.Foundation (you're probably already here).

## Submodule
The InnovationWeb project defines a submodule dependency on [Bam.Net](https://github.com/BryanApellanes/Bam.Net).  To ensure submodules are updated when you clone the repository use the following command:

```
git clone --recursive-submodules https://dev.azure.com/premera-testkitchen/_git/TestKitchen.Foundation
```

If you have already cloned the repository and need to update the submodule use the following command:

```
git pull --recursive-submodules
```

[Bam.Net](https://github.com/BryanApellanes/Bam.Net) and the associated projects expect nuget packages in the path C:\bam\nuget\packages.  Use the following command
to restore nuget packages to the appropriate path:

```
nuget restore Bam.Net.Nuget.sln -PackagesDirectory c:\bam\nuget\packages
```

## Deployment
This project is currently deployed internally to Premera with no external access possible.  The application is deployed to the server specified below:

```
\\mltdsapv0003\D$\TestKitchen
```

At the time of this writing, a DNS entry has not been entered for this application so a hosts file entry is necessary for it to function correctly.  See [Hosts File](../).

# Explore
Take a look at the README files for the Innovation projects.
- [InnovationLib](../InnovationLib)
- [InnovationLib.fx](../InnovationLib.fx)
- [InnovationWeb](../InnovationWeb)
- [InnovationSso](../InnovationSso)