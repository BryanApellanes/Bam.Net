﻿using Bam.Net.UserAccounts;
using Innovation;
using Innovation.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InnovationWeb.Model
{
    public class BetaProgramPageModel : PageModel
    {
        protected const string AdminRole = "Admin";
        public BetaProgramPageModel(BetaProgramService service, IRoleReader roleReader)
        {
            BetaProgramService = service;
            RoleReader = roleReader;
        }

        public BetaProgramService BetaProgramService { get; set; }
        public IRoleReader RoleReader { get; set; }

        public bool IsAdmin
        {
            get
            {
                return InRole(AdminRole);
            }
        }

        public bool InRole(string roleName)
        {
            return RoleReader.IsUserInRole(UserName, roleName);
        }

        public string UserName
        {
            get
            {
                string userName = User?.Identity?.Name;
                string[] split = userName.Split('\\', StringSplitOptions.RemoveEmptyEntries);
                if (split.Length == 2)
                {
                    userName = split[1];
                }
                return userName;
            }
        }

        public List<BetaProgram> BetaPrograms { get; set; }
        public string Message { get; set; }
        public bool Error { get; set; }

        public virtual IActionResult OnGet()
        {
            BetaProgramResponse<List<BetaProgram>> response = BetaProgramService.ListPrograms();
            if (!response.Success)
            {
                Error = true;
                Message = response.Message;
            }
            BetaPrograms = response.Data;
            return Page();
        }
    }
}
