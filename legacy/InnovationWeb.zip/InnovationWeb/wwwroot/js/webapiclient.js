﻿var webapiclient = (function () {

    return {
        listPrograms: function (success, error) {
            $.ajax({
                type: 'GET',
                url: '/api/betaprogram',
                contentType: 'application/json',
                dataType: 'json',
                success: function (data) {
                    if (success !== undefined) {
                        success(data);
                    }
                },
                error: function (e) {
                    if (error !== undefined) {
                        error(e);
                    }
                }
            })
        },
        getParticipation: function (success, error) {
            $.ajax({
                type: 'GET',
                url: '/api/betaprogram/participation',
                contentType: 'application/json',
                dataType: 'json',
                success: function (data) {
                    if (success !== undefined) {
                        success(data);
                    }
                },
                error: function (e) {
                    if (error !== undefined) {
                        error(e);
                    }
                }
            })
        },
        addProgram: function (programName, success, error) {            
            $.ajax({
                type: 'POST',
                url: '/api/betaprogram',
                data: JSON.stringify(programName),
                contentType: 'application/json',
                dataType: 'json',
                success: function (data) {
                    if (success !== undefined) {
                        success(data);
                    }
                },
                error: function (e) {
                    if (error !== undefined) {
                        error(e);
                    }
                }
            })
        },
        deleteProgram: function (programName, success, error) {
            $.ajax({
                type: 'GET',
                url: `/api/betaprogram/${programName}/delete`,
                data: programName,
                contentType: 'application/json',
                dataType: 'json',
                success: function (data) {
                    if (success !== undefined) {
                        success(data);
                    }
                },
                error: function (e) {
                    if (error !== undefined) {
                        error(e);
                    }
                }
            })
        },
        optIn: function (programName, success, error) {
            $.ajax({
                type: 'POST',
                url: `/api/betaprogram/optin`,
                data: JSON.stringify(programName),
                contentType: 'application/json',
                dataType: 'json',
                success: function (data) {
                    if (success !== undefined) {
                        success(data);
                    }
                },
                error: function (e) {
                    if (error !== undefined) {
                        error(e);
                    }
                }
            })
        },
        optOut: function (programName, success, error) {
            $.ajax({
                type: 'POST',
                url: `/api/betaprogram/optout` ,
                data: JSON.stringify(programName),
                contentType: 'application/json',
                dataType: 'json',
                success: function (data) {
                    if (success !== undefined) {
                        success(data);
                    }
                },
                error: function (e) {
                    if (error !== undefined) {
                        error(e);
                    }
                }
            })
        }
    }
})()