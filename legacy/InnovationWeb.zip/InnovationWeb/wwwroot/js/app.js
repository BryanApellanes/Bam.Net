﻿var app = (function (wapi) {
    var api = wapi,
        betaProgramsListId = "#betaProgramsList",
        participationListId = "#participationList";

    return {
        init: function () {

        },
        message: function (msg) {
            return new Promise((resolve, reject) => {
                var messageModal = $("#message");
                $("#message-content", messageModal).text(msg);
                messageModal.on('hidden.bs.modal', () => {
                    resolve();
                });
                messageModal.removeClass("hidden").modal();                
            })
        },
        refreshBetaPrograms: function () {
            var _app = app;
            return new Promise((resolve, reject) => {
                api.listPrograms(data => {
                    if (data.success) {
                        var betaProgramsList = $(betaProgramsListId).empty(),
                            programsContent = '';
                        for (var i = 0; i < data.data.length; i++) {
                            var program = data.data[i];
                            programsContent += `<li>${program.name} <button class="btn delete-program-button" data-program-id="${program.uuid}">delete</button><img src="/images/Ajax-loader.gif" alt="working" class="hidden" id="deleteSpinner-${program.uuid}" /></li>`;
                        }
                        betaProgramsList.html(programsContent);
                        resolve();
                    } else {
                        _app.message(data.message);
                        reject(data.message);
                    }            
                },
                    error => reject()
                );
            })
        },
        refreshOptInList: function () {
            var _app = app;
            return new Promise((resolve, reject) => {
                api.getParticipation(data => {
                    if (data.success) {
                        var participationList = $(participationListId).empty(),
                            participationContent = '';
                        for (var i = 0; i < data.data.length; i++) {
                            var participation = data.data[i],
                                optInHtml = `<button class="btn optin-program-button" data-program-id="${participation.programUuid}">opt-in</button>`,
                                optOutHtml = `<button class="btn optout-program-button" data-program-id="${participation.programUuid}">opt-out</button>`;
                            participationContent += `<li>${participation.programName} ${participation.isOptedIn ? optOutHtml : optInHtml}<img src="/images/Ajax-loader.gif" alt="working" class="hidden" id="optinout-spinner-${participation.programUuid}" /></li>`;
                        }
                        participationList.html(participationContent);
                        resolve();
                    } else {
                        _app.message(data.message);
                        reject(data.message);
                    }
                },
                    error => reject()
                );
            })
        }
    }
})(webapiclient)