﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Innovation;
using Innovation.Data;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace InnovationWeb.Controllers
{
    [Route("api/[controller]")]
    public class BetaProgramController : Controller
    {
        public BetaProgramController(BetaProgramService betaProgramService)
        {
            BetaProgramService = betaProgramService;
        }

        public BetaProgramService BetaProgramService { get; set; }

        // GET: api/<controller>
        [HttpGet]
        public BetaProgramResponse<List<BetaProgram>> ListPrograms()
        {
            return BetaProgramService.ListPrograms();
        }

        [HttpGet("{programName}")]
        public BetaProgramResponse<List<BetaProgramParticipant>> Participants(string programName)
        {
            return BetaProgramService.GetParticipants(programName);
        }

        [HttpGet("participation")]
        public BetaProgramResponse<List<BetaProgramParticipation>> Participation()
        {
            string userName = User?.Identity?.Name;
            return BetaProgramService.GetParticipation(userName);
        }

        // GET api/<controller>/5
        [HttpGet("{name}")]
        public BetaProgramResponse<BetaProgram> GetProgram(string name)
        {
            return BetaProgramService.GetBetaProgram(name);
        }

        // POST api/<controller>
        [HttpPost]
        public BetaProgramResponse<BetaProgram> AddProgram([FromBody]BetaProgram program)
        {
            return BetaProgramService.AddProgram(program.Name, program.Description);
        }

        [HttpPost("optin")]
        public BetaProgramResponse<bool> PostOptIn([FromBody]string programName)
        {
            string userName = User?.Identity?.Name;
            return BetaProgramService.OptIn(programName, userName);
        }

        [HttpGet("{programName}/optin")]
        public BetaProgramResponse<bool> GetOptIn(string programName)
        {
            string userName = User?.Identity?.Name;
            return BetaProgramService.OptIn(programName, userName);
        }

        [HttpGet("{programName}/optout")]
        public BetaProgramResponse<bool> GetOptOut(string programName)
        {
            string userName = User?.Identity?.Name;
            return BetaProgramService.OptIn(programName, userName);
        }

        [HttpPost("optout")]
        public BetaProgramResponse<bool> OptOut([FromBody]string programName)
        {
            string userName = User?.Identity?.Name;
            return BetaProgramService.OptOut(programName, userName);
        }

        [HttpGet("{programName}/delete")]
        public BetaProgramResponse<bool> GetDeleteProgram(string programName)
        {
            return BetaProgramService.DeleteProgram(programName);
        }

        [HttpDelete("{programName}")]
        public BetaProgramResponse<bool> DeleteProgram(string programName)
        {
            return BetaProgramService.DeleteProgram(programName);
        }
    }
}
