/*
	Copyright © Bryan Apellanes 2015  
*/
var testinclude =(function($, b, d, win){
    "use strict";

    return {

    }
})(jQuery, bam, dao, window || {});