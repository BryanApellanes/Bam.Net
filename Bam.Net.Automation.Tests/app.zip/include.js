/*
	Copyright © Bryan Apellanes 2015  
*/
; var include = {
	css:[
        
	],
    scripts: [
        "/js/testinclude.js"
    ]
};