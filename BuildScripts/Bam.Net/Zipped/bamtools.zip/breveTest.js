﻿var breve = {
    monkey: "Object",
    name: "String",
    tail: "bool"
}